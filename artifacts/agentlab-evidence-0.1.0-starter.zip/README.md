# Agent Lab Evidence 0.1.0

Standalone loopback MCP2 report evidence service. Use an existing Python3.11 and uv. Linux/Python3.11.4 was tested. No source checkout, Deep Agents, LlamaIndex, model weights or model API key is required.

From this extracted directory, on an authorized server:

    uv sync --python python3.11 --project runtime --frozen --no-install-project --no-default-groups
    uv pip install --python runtime/.venv/bin/python --offline --no-deps ./agentlab_evidence-0.1.0-py3-none-any.whl
    uv pip check --python runtime/.venv/bin/python
    runtime/.venv/bin/agentlab-evidence --root reports --manifest reports/catalog.json --check
    runtime/.venv/bin/agentlab-evidence --root reports --manifest reports/catalog.json --port 18856

The frozen runtime sync downloads dependencies from PyPI; the following own-wheel install is offline. Connect a compatible MCP client to http://127.0.0.1:18856/mcp on the same host. The health endpoint is /health. Stop the foreground service when finished. python -m agentlab_evidence is also available in that environment. No public listener or hosted website backend is created.

The nine reports are real, fixed public evidence from source snapshot cb67290a9ced302834f8458adf94b78bc64246bd. They are historical inputs, not a live GitHub status feed or the latest core test report. Replace them only with an operator-curated manifest containing bounded relative JSON paths and exact SHA256s; see the repository docs for the schema. Never add private connection documents, tokens or active run state.

Tools: begin_audit, list_reports, read_report, verify_assessment, audit_status, close_audit. Keep audit IDs/read receipts on the client and present receipts for verification. A receipt only proves possession of a report result. Verdict truth and free prose remain explicitly unchecked. Defaults:32 process-local audit contexts,600-second TTL,16 costly operations and8 reads per audit; close works after operation exhaustion. No authenticated multiuser service or durable cross-process audit recovery is promised.

The installed wheel passed eight artifact controls outside the checkout, including real report receipts, wrong JSON type/borrowed receipt rejection, changed report preflight/live rejection, planned restart invalidation and close after exhaustion. The current main project separately passes130 core tests; scopes are not added. Zero neural/GPU requests in this validation. Original9B model timeouts are not rerun or regraded. The wheel has not been uploaded to PyPI.

CHECKSUMS.json records each payload's SHA256/size except itself. Verify the outer starter SHA256 against the repository/site receipt as well; this is integrity metadata, not publisher authentication.
