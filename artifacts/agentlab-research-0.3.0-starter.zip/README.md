# AgentLab research retrieval 0.3.0 · CPU starter

Standalone LlamaIndex/E5 retrieval and loopback MCP. Includes the server-built
wheel, the unchanged frozen Linux x86_64/Python3.11 CPU runtime lock, and a
sample query batch. No model weights, dataset text, private index or credentials.
The runtime project is still named/versioned 0.2.0 because its dependencies did
not change; the installed application is 0.3.0.

## Install

Use an experiment server with Python3.11 and uv:

```sh
uv sync --project extras/research-library --frozen --no-install-project --no-default-groups
uv pip install --python extras/research-library/.venv/bin/python --no-deps artifacts/agentlab_research-0.3.0-py3-none-any.whl
uv pip check --python extras/research-library/.venv/bin/python
extras/research-library/.venv/bin/agentlab-research --help
```

The lock selects torch2.6.0+cpu from the explicit official PyTorch CPU index.
Obtain the six E5 assets pinned by the installed
`agentlab_research/research_model_assets.json` (model revision
614241f622f53c4eeff9890bdc4f31cfecc418b3). Then:

```sh
extras/research-library/.venv/bin/agentlab-research check-model --directory /path/to/e5
extras/research-library/.venv/bin/agentlab-research prepare --directory /path/to/docs --output /tmp/new-research-input --base-url https://example.org/versioned/docs/
extras/research-library/.venv/bin/agentlab-research ingest --manifest /tmp/new-research-input/collection.json --store /tmp/new-research-store --model-dir /path/to/e5 --embed-batch-size 16
extras/research-library/.venv/bin/agentlab-research search-batch --queries examples/questions.jsonl --output /tmp/new-results.jsonl --store /tmp/new-research-store --model-dir /path/to/e5 --top-k 10
extras/research-library/.venv/bin/agentlab-research read --store /tmp/new-research-store --citation-id '<generation>:<node_id>'
extras/research-library/.venv/bin/agentlab-research serve --store /tmp/new-research-store --model-dir /path/to/e5 --port 18863
```

Replace example paths/URLs with your own matching immutable sources. The tool
does not verify a caller's claimed source URL. `check-model` checks hashes and
creates a missing manifest, without inference. Ingest/search run real CPU E5.

`prepare-pdf --manifest /path/to/intake.json --output /tmp/new-paper-input`
accepts an explicit manifest such as:

```json
{"version":1,"pdfs":[{"path":"paper.pdf","url":"https://example.org/paper-v3.pdf","title":"Paper title"}]}
```

Paths are local relative to the manifest; PDF URLs are not downloaded.
Digital-text PDFs only, no OCR/layout reconstruction; 32 PDFs/256 physical
pages total, 32MiB each/64MiB original bytes, 512KiB per extracted page and
16MiB extracted text. Text intake supports 8192 sources/512KiB each/16MiB total.

## Contracts and limits

Search returns candidate passages with source hashes, generation IDs and
character/line ranges; PDF results also carry the original PDF hash and physical
page. It generates no answer. MCP exposes `list_sources`, `search_sources` and
`read_citation` at http://127.0.0.1:18863/mcp, with at most 8 search results.
Offline search accepts top-k 1–32, candidate-node window max(24,4*k).

A query batch contains at most512 unique id/query rows,1MiB and2000characters
per question. BM25, semantic and RRF results share one captured generation;
semantic/RRF share each query vector. Results contain source text. The final
JSONL is published after all rows succeed; a failure retains .partial and
cannot be resumed. Existing output/partial files are never overwritten.
Use new paths and avoid concurrent writers to the trusted local store.
Snapshots must be reopened to observe a new generation or revalidate disk.

The application reports process-local embedding counts. Durable quotas and
resource supervision belong to the experiment driver, not a built-in service
feature. Hashes establish integrity within a trusted store, not authenticity
against someone who can rewrite the complete store.

## Verification scope

The exact included wheel was built on the server and its 8 canonical module/data
files matched source hashes. A new application namespace passed dependency and
console checks while reusing the prior frozen third-party modules through a
read-only view with copied distribution metadata. The evaluation used the larger frozen reading-assistant dependency environment;
its90 shared dependency versions match this smaller retrieval lock. This was
not a new clean reinstall of every dependency. Earlier clean CPU dependency installation is
recorded separately. New source controls:7 snapshot/batch,4 scoring,1 real TCP
MCP; existing21 lifecycle/intake/PDF regressions are overlapping history and
reported separately. Actual full-corpus retrieval metrics are in the repository;
this starter README does not infer a quality score from those controls.

Project source, actual results and preserved failures:
https://github.com/1137423918/AgentReliabilityLab
